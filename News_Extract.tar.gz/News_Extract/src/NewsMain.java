import news.gui.NewsDisplay;


public class NewsMain {

	public static void main(String[] args) {
		new NewsDisplay().initiate();
	}

}
