package news.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

import news.data.NewsData;
import news.extract.ExtractIndianExpress;
import news.extract.ExtractORF;
import news.extract.ExtractTheHindu;
import news.extract.NewsExtract;
import news.extract.NewsExtract2;

public class NewsDisplay {

	private JFrame newsFrame;
	private JButton orfButton,hinduButton,ieButton,clearButton;
	private JPanel bPanel,mainPanel;
	private JTextArea mainDisplay;
	private JScrollPane newsScroller;
	
	public void initiate() {
		
		mainDisplay = new JTextArea(40,110);
		mainDisplay.setEditable(false);
		newsScroller = new JScrollPane(mainDisplay);
		
		orfButton = new JButton("ORF");
		hinduButton = new JButton("Hindu");
		ieButton = new JButton("IE");
		clearButton = new JButton("Clear");
		orfButton.addActionListener(new NewsButtonListener());
		hinduButton.addActionListener(new NewsButtonListener());
		ieButton.addActionListener(new NewsButtonListener());
		clearButton.addActionListener( new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mainDisplay.setText(null);
			}
			}
		);
		bPanel = new JPanel();
		bPanel.setLayout(new GridLayout(10,1));
		bPanel.add(orfButton);bPanel.add(ieButton);bPanel.add(hinduButton);bPanel.add(clearButton);
		/*try {
			bPanel.add(new JLabel(new ImageIcon(ImageIO.read(new URL("http://www.mkyong.com/image/mypic.jpg")))));
		} catch (IOException e1) {
			e1.printStackTrace();
		}*/
		
		newsFrame = new JFrame("International news from the specified sources");
		newsFrame.getContentPane().add(BorderLayout.NORTH,new JPanel());
		newsFrame.getContentPane().add(BorderLayout.EAST,new JPanel());
		newsFrame.getContentPane().add(BorderLayout.SOUTH,new JPanel());
		newsFrame.getContentPane().add(BorderLayout.CENTER,newsScroller);
		newsFrame.getContentPane().add(BorderLayout.WEST,bPanel);
		newsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
		newsFrame.setSize(size);
		newsFrame.setVisible(true);
	}
	
	private void displayArticles(ArrayList<StringBuilder> articlelist2, ArrayList<URL[]> url_list) {
		
		
		mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(articlelist2.size(),1));
		System.out.println(articlelist2.size());
		System.out.println(url_list.size());
		try {
			bPanel.add(new JLabel(new ImageIcon(ImageIO.read(new URL("http://www.mkyong.com/image/mypic.jpg")))));
			for(int i=0;i<articlelist2.size();i++) {
				JLabel href = new JLabel(url_list.get(i)[0].getPath());
				JLabel content = new JLabel(articlelist2.get(i).toString());
				JPanel article = new JPanel();
				article.setLayout(new GridLayout(1,1));
				article.add(href);
				article.add(content);
				//JLabel image = new JLabel(new ImageIcon(ImageIO.read(url_list.get(i)[0])));
				JPanel post = new JPanel();
				//post.setLayout(new GridLayout(1,2));
				//post.add(image);
				post.add(article);
				mainPanel.add(post);
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			newsFrame.getContentPane().add(BorderLayout.CENTER,mainPanel);
		}
	}
	
	private class NewsButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			
			JButton news = (JButton) event.getSource();
			String src = news.getText();
			ArrayList<StringBuilder> articlelist2=null;
			ArrayList<URL[]> article_url_list = null;
			mainDisplay.setText(null);
			if(src.equals("ORF")) {
				articlelist2=ExtractORF.readSiteORF();
				article_url_list = ExtractORF.getUrlList();
			}
			else if(src.equals("Hindu")) {
				articlelist2=ExtractTheHindu.readSiteTheHindu();
			}
			else if(src.equals("IE")) {
				articlelist2=ExtractIndianExpress.readSiteTheIndianExpress();
			}
			for(StringBuilder post: articlelist2)
			mainDisplay.append(post.toString());
			//displayArticles(articlelist2,article_url_list);
		}
	}
}
