package news.extract;

import java.io.IOException;
import java.util.ArrayList;

import news.data.NewsData;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ExtractTheHindu {

	public static ArrayList<StringBuilder> readSiteTheHindu() {

		String url = NewsData.THE_HINDU;
		final String delim = "------------------------------------";
		ArrayList<StringBuilder> articlelist = new ArrayList<StringBuilder>();

		try {
			/*	THE HINDU HTML structure
			 * 	container section-container(3)
			 * 		main
			 * 			row
			 * 				--50_1x_StoryCard mobile-padding [n]
			 * 					--col-lg-6 col-md-6 col-sm-6 col-xs-12
			 * 						--story-card
			 * 							--story-card news
			 * 								--<h3>
			 * 									--<a href> text
			 * 				33_1x_OtherStoryCard mobile-padding [n]
			 * 					col-lg-4 col-md-4 col-sm-4 col-xs-12 hover-icon
			 * 						Other-StoryCard
			 * 							--<h3>
			 * 								<a href> text
			 * 							<a> text (p)
			 */
			
			Document doc = Jsoup.connect(url).get();
			StringBuilder article_title = new StringBuilder();
			article_title.append(doc.title()).append("\n").append(delim).append("\n");
			articlelist.add(article_title);
			
			int c=1;
			Element container = doc.getElementsByClass("container section-container ").get(2);
			container = container.getElementsByClass("main").get(0).getElementsByClass("row").get(0);
			Elements articles = container.getElementsByClass("33_1x_OtherStoryCard mobile-padding");
			
			for(Element a:articles) {
				Element a1=a;
				a1=a1.getElementsByClass("col-lg-4 col-md-4 col-sm-4 col-xs-12 hover-icon").get(0);
				a1=a1.getElementsByClass("Other-StoryCard").get(0);
				String c1="Article number "+c++;
				
				Element header = a1.getElementsByTag("a").get(0);
				String header_href = header.attr("href");
				String header_text = header.text();
				
				Element content = a1.getElementsByTag("a").get(1);
				String para = content.text();
				
				StringBuilder article_content = new StringBuilder();
				article_content.append(c1).append("\n").append(header_text).append("\n").append(para).append("\n");
				article_content.append(delim).append("\n");
				articlelist.add(article_content);
			}

		} catch(IOException e) {
			e.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return articlelist;
	}

}
