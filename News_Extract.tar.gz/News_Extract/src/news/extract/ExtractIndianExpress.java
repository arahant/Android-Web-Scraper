package news.extract;

import java.io.IOException;
import java.util.ArrayList;

import news.data.NewsData;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ExtractIndianExpress {

	//Extracting news articles from THE INDIAN EXPRESS
	public static ArrayList<StringBuilder> readSiteTheIndianExpress() {

		final String url = NewsData.THE_INDIAN_EXPRESS;
		final String delim = "------------------------------------";
		ArrayList<StringBuilder> articlelist = new ArrayList<StringBuilder>();

		try {
			/*	INDIAN EXPRESS HTML structure
			 * 	lead-story
			 * 		short-info
			 * 			<h1>
			 * 				<a>
			 * 			<p>
			 * 	--second-stories
			 * 		--story [2]+story last
			 * 	article first
			 * 		title
			 * 			<a href> text
			 * 		<p>
			 * 	articles[n(36)] 
			 * */

			//extracting title
			Document doc = Jsoup.connect(url).get();
			StringBuilder article_title = new StringBuilder();
			article_title.append(doc.title()).append("\n").append(delim).append("\n");
			articlelist.add(article_title);

			int c=1;

			//Extracting lead story
			Element leadstory = doc.getElementsByClass("lead-story").get(0).getElementsByClass("short-info").get(0);
			StringBuilder article_lead = new StringBuilder();

			String a1="Article number "+c++;
			Element lead_header = leadstory.getElementsByTag("h1").get(0).getElementsByTag("a").get(0);
			String lead_href = lead_header.attr("href");
			String lead_header_text = lead_header.text();
			String lead_para = leadstory.getElementsByTag("p").get(0).text();

			article_lead.append(a1).append("\n").append(lead_header_text).append("\n").append(lead_para).append("\n").append(delim).append("\n");
			articlelist.add(article_lead);


			/*//Extracting second stories
				Element second_stories = doc.getElementsByClass("second-stories").get(0);
				Elements story = second_stories.getElementsByClass("story");
				story.add ( second_stories.getElementsByClass("story last").get(0) );
				for(Element s:story) {
					String s1="Article number "+c++;
					String s2="Header: "+s.getElementsByTag("h6").get(0).text();
					String s3="Content: "+s.getElementsByTag("p").get(0).text();
					String s4="------------------------------------";
					String s5[]={s1,s2,s3,s4};
					articlelist.add(s5);
				}*/

			//Extracting headline first
			StringBuilder article_first = new StringBuilder();
			String b1="Article number "+c++;

			Element headline_first = doc.getElementsByClass("articles first").get(0);

			//header
			Element header_first = headline_first.getElementsByClass("title").get(0).getElementsByTag("a").get(0);
			String header_first_href = header_first.attr("href");
			String header_first_text = header_first.text();

			//paragraph (text)
			String content_first = headline_first.getElementsByTag("p").get(0).text();
			article_first.append(b1).append("\n").append(header_first_text).append("\n").append(content_first).append("\n").append(delim).append("\n");
			articlelist.add(article_first);


			//extracting remaining headlines
			Elements headlines_rest = doc.getElementsByClass("articles");
			for(Element h:headlines_rest) {

				StringBuilder article_rest = new StringBuilder();
				String c1="Article number "+c++;

				Element header_rest = h.getElementsByClass("title").get(0).getElementsByTag("a").get(0);
				String header_rest_href = header_rest.attr("href");
				String header_rest_text = header_rest.text();

				//paragraph (text)
				String content_rest = h.getElementsByTag("p").get(0).text();
				article_first.append(c1).append("\n").append(header_rest_text).append("\n").append(content_rest).append("\n").append(delim).append("\n");
				articlelist.add(article_rest);
			}

		} catch(IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return articlelist;
	}

}
