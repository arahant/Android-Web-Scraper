package news.data;

public class NewsData {
	
	//International sources
	public static final String THE_DIPLOMAT= "http://thediplomat.com";
	
	//Indian sources
	public static final String THE_HINDU = "http://www.thehindu.com/news/international/";
	public static final String THE_INDIAN_EXPRESS = "http://indianexpress.com/section/world/";
	public static final String ORF = "http://www.orfonline.org/";

}
