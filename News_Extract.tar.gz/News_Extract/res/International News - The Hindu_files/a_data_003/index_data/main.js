// JavaScript Document

// config
var currentLoop = 0;
var totalLoops = 0;
var endFrameDelay = 4;
var useReplayBtn = true;

// content
var container;
var bgImage01, bgImage02, bgImage03;
var backgroundWhite;
var copy_frame01, copy_frame02, copy_frame03, copy_frame04, copy_frame05, copy_terms;
var logoBA01,logoBA02, cta;
var btnReplay;

var frameWaitTimer;

TweenLite.lagSmoothing(0); // stops tweenlite animation messing up when switching between browser tabs

startAd = function()
{
    // content        
    container = document.getElementById("container");
    bgImage01 = document.getElementById("bgImage01");
    bgImage02 = document.getElementById("bgImage02");
    bgImage03 = document.getElementById("bgImage03");
    backgroundWhite = document.getElementById("backgroundWhite");
    copy_frame01 = document.getElementById("copy_frame01");
    copy_frame02 = document.getElementById("copy_frame02");
    copy_frame03 = document.getElementById("copy_frame03");
    copy_frame04 = document.getElementById("copy_frame04");
    copy_frame05 = document.getElementById("copy_frame05");
    copy_terms = document.getElementById("copy_terms");
    logoBA01 = document.getElementById("logoBA01");
    logoBA02 = document.getElementById("logoBA02");
    cta = document.getElementById("cta");
    btnReplay = document.getElementById("btnReplay");

    // activate btns
    btnReplay.addEventListener('click', btnReplay_clickHandler, false);
    btnReplay.addEventListener("mouseover", btnReplay_overHandler, false);
    btnReplay.addEventListener("mouseout", btnReplay_outHandler, false);
    
    // show Ad
    container.style.display = "block";

    showFrame(1);
}

function btnReplay_clickHandler() 
{
    showFrame(1);
    console.log("btnReplay_clickHandler");
}

function btnReplay_overHandler() 
{
    //console.log("btnReplay_overHandler");
    TweenLite.to(btnReplay, 0.4, {rotation:360, delay:0});
}

function btnReplay_outHandler() 
{
    //console.log("btnReplay_outHandler");
    TweenLite.to(btnReplay, 0.2, {rotation:0, delay:0});
}



var holdFrame = function(frame, time) {
    var delay = time*1000;
    frameWaitTimer = window.setTimeout(function(){showFrame(frame);}, delay);
}


/**
 * switch statement for animating ad
 */
function showFrame(id)
{
    console.log('showing frame ' + id);
    switch(id) {

        //show frame 1
        case 1:

            resetBanner();

            // show frame content
            TweenLite.to(copy_frame01, 0.5, {alpha:1, delay:0, ease:Linear.easeNone});

            holdFrame(2, 2.5);
            break;

        //show frame 2
        case 2:
            // hide prev content
            TweenLite.to(copy_frame01, 0.3, {alpha:0, delay:0, ease:Linear.easeNone});

            // show frame content
            TweenLite.to(bgImage02, 0.5, {alpha:1, delay:0.3, ease:Linear.easeNone});
            TweenLite.to(copy_frame02, 0.5, {alpha:1, delay:1, ease:Linear.easeNone});
          
            holdFrame(3, 3.4);
            break;

        //show frame 3
        case 3:

            // hide prev content
            TweenLite.to(copy_frame02, 0.3, {alpha:0, delay:0, ease:Linear.easeNone});

            // show frame content
            TweenLite.to(bgImage03, 0.5, {alpha:1, delay:0.3, ease:Linear.easeNone});
            TweenLite.to(copy_frame03, 0.5, {alpha:1, delay:1, ease:Linear.easeNone});

            holdFrame(4, 3.4);
            break;

        //show frame 4
        case 4:

            // hide prev content
            TweenLite.to(copy_frame03, 0.3, {alpha:0, delay:0, ease:Linear.easeNone});

            // show frame content
            TweenLite.to(backgroundWhite, 0.5, {alpha:1, delay:0.3, ease:Linear.easeNone});
            TweenLite.to(logoBA02, 0.5, {alpha:1, delay:0.3, ease:Linear.easeNone});
            TweenLite.to(copy_frame04, 0.5, {alpha:1, delay:1, ease:Linear.easeNone});

            holdFrame(5, 3.4);
            break;

        //show frame 5
        case 5:

             // hide prev content
            TweenLite.to(copy_frame04, 0.3, {alpha:0, delay:0});

            // show frame content
            TweenLite.to([copy_frame05,copy_terms], 0.5, {alpha:1, delay:0.5, ease:Linear.easeNone});
            TweenLite.to(cta, 0.5, {alpha:1, delay:0.5});

            // check if banner needs to loop
            TweenLite.delayedCall(1.1, checkForLooping);

            break;
    }
}

/**
 * function checks if banner should loop or show replay btn
 */
function checkForLooping()
{
    if(currentLoop < totalLoops) // loop baner
    {
        TweenLite.delayedCall(endFrameDelay, showFrame, [1]);
        currentLoop++;
    }
    else // show replay btn
    {   
        if(useReplayBtn === true)
        {
            btnReplay.style.display = "block";
        }
    }
}



/**
 * function resets content on end frame to initial states
 */
function resetBanner()
{
    TweenLite.set([copy_frame05,copy_terms,cta,bgImage02,bgImage03,backgroundWhite,logoBA02], {alpha:0});
    TweenLite.set([bgImage01], {alpha:1});
    btnReplay.style.display = "none";


}
