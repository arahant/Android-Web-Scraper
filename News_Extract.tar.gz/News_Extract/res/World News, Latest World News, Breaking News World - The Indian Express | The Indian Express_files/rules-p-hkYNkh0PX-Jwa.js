/*
 Quantcast measurement tag
 Copyright (c) 2008-2017, Quantcast Corp.
*/
(function(a,b,c){})("p-hkYNkh0PX-Jwa",window,document);