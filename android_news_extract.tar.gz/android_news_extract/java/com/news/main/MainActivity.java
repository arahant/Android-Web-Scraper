package com.news.main;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.NavigationView.OnNavigationItemSelectedListener;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.util.Linkify;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.news.extract.ExtractIndianExpress;
import com.news.extract.ExtractORF;
import com.news.extract.ExtractTheHindu;

import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnNavigationItemSelectedListener {

    private TextView title_display;
    private LinearLayout news_linear;
    private static Context context;
    private LinearLayout.LayoutParams article_param;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.srclist);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_SHORT)
                  //      .setAction("Action", null).show();
                Toast.makeText(getApplicationContext(),"Select",Toast.LENGTH_SHORT);
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        title_display = (TextView) findViewById(R.id.title);
        news_linear = (LinearLayout) findViewById(R.id.news_linear);
        article_param = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        article_param.setMargins(10,10,10,0);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    // Handle action bar item clicks here. The action bar will
    // automatically handle clicks on the Home/Up button, so long
    // as you specify a parent activity in AndroidManifest.xml.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // Handle navigation view item clicks here.
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.news_orf) {
            displayNewsORF();
        }
        else if (id == R.id.news_ie) {
            displayNewsIE();
        }
        else if (id == R.id.news_hindu) {
            displayNewsHindu();
        }
        else if (id == R.id.nav_share) {

        }
        else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    /*private class LinkListener implements OnClickListener {

        private URL url;
        public LinkListener(URL url) {
            this.url=url;
        }

        @Override
        public void onClick(View view) {
            Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(url.toString()));
            Intent choose = Intent.createChooser(browser,url.toString());
            startActivity(choose);
        }
    }*/

    private void displayNewsORF() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<StringBuilder> articlelist = ExtractORF.readSite();
                ArrayList<URL[]> url_list = ExtractORF.getUrlList();
                final ArrayList<TextView> newslist = new ArrayList<TextView>();

                for (int i=0;i<articlelist.size();i++) {

                    final URL url = url_list.get(i)[0];
                    StringBuilder article = articlelist.get(i);//.append("\n").append(url);

                    TextView temp = new TextView(context);
                    temp.setText(article.toString());
                    temp.setTextColor(Color.BLACK);
                    temp.setBackgroundColor(Color.LTGRAY);
                    temp.setLayoutParams(article_param);
                    temp.setPadding(10,10,10,10);

                    Linkify.addLinks(temp,Linkify.WEB_URLS);
                    //temp.setOnClickListener(new LinkListener(url));
                    newslist.add(temp);
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        news_linear.removeAllViews();
                        for(TextView temp:newslist) {
                            news_linear.addView(temp);
                        }
                    }
                });
            }
        }).start();
    }

    private void displayNewsIE() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<StringBuilder> articlelist = ExtractIndianExpress.readSite();
                ArrayList<URL[]> url_list = ExtractIndianExpress.getUrlList();
                final ArrayList<TextView> newslist = new ArrayList<TextView>();

                for (int i=0;i<articlelist.size();i++) {

                    final URL url = url_list.get(i)[0];
                    StringBuilder article = articlelist.get(i);//.append("\n").append(url);

                    TextView temp = new TextView(context);
                    temp.setText(article.toString());
                    temp.setTextColor(Color.BLACK);
                    temp.setBackgroundColor(Color.LTGRAY);
                    temp.setLayoutParams(article_param);
                    temp.setPadding(10,10,10,10);

                    Linkify.addLinks(temp,Linkify.WEB_URLS);
                    //temp.setOnClickListener(new LinkListener(url));
                    newslist.add(temp);
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        news_linear.removeAllViews();
                        for(TextView temp:newslist)
                            news_linear.addView(temp);
                    }
                });
            }
        }).start();
    }

    private void displayNewsHindu() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<StringBuilder> articlelist = ExtractTheHindu.readSite();
                ArrayList<URL[]> url_list = ExtractTheHindu.getUrlList();
                final ArrayList<TextView> newslist = new ArrayList<TextView>();

                for (int i=0;i<articlelist.size();i++) {

                    final URL url = url_list.get(i)[0];
                    StringBuilder article = articlelist.get(i);//.append("\n").append(url);

                    TextView temp = new TextView(context);
                    temp.setText(article.toString());
                    temp.setTextColor(Color.BLACK);
                    temp.setBackgroundColor(Color.LTGRAY);
                    temp.setLayoutParams(article_param);
                    temp.setPadding(10,10,10,10);

                    Linkify.addLinks(temp,Linkify.WEB_URLS);
                    //temp.setOnClickListener(new LinkListener(url));
                    newslist.add(temp);
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        news_linear.removeAllViews();
                        for(TextView temp:newslist)
                            news_linear.addView(temp);
                    }
                });
            }
        }).start();
    }

}
