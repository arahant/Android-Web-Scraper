package com.news.extract;

public interface ExtractNews {

}
